module.exports = {
  rules: {
    'no-restricted-syntax': 'off'
  }
}